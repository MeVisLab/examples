#
# Copyright 2023, MeVis Medical Solutions AG
#
# The user may use this file in accordance with the license agreement provided with
# the Software or, alternatively, in accordance with the terms contained in a
# written agreement between the user and MeVis Medical Solutions AG.
#
# For further information use the contact form at https://www.mevislab.de/contact
#
# ----------------------------------------------------------------------------

#
#  \file    TutorialSummary.py
#  \author  MeVis Medical Solutions AG
#  \date    2023-01-16
#
#  Macro Module for MeVisLab Tutorials

# ----------------------------------------------------------------------------

from mevis import *
