#
# Copyright 2025, MeVis Medical Solutions AG
#
# The user may use this file in accordance with the license agreement provided with
# the Software or, alternatively, in accordance with the terms contained in a
# written agreement between the user and MeVis Medical Solutions AG.
#
# For further information, use the contact form at https://www.mevislab.de/contact
#
# ----------------------------------------------------------------------------
# Macro module MyItemModelView
# 
#  Example for using the ItemModelView
# ----------------------------------------------------------------------------

# For available scripting functions, see
# https://mevislabdownloads.mevis.de/docs/current/MeVisLab/Resources/Documentation/Publish/SDK/ScriptingReference/python.html
import mevislab
from mevis import *

gAttributes = ["patientName", "patientBirthdate", "studyDescription", "studyDate", "modality", "seriesDescription", "seriesDate", "sopInstanceUID"]
gModel = None
gNextId = 0
gInitializing = False


def imageChanged(field: "mevislab.MLABField "):
    global gModel, gNextId, gInitializing
    gInitializing = True
    gModel = MyItemModel()
    gNextId = 0
    if gModel:
        gModel.makeCurrent()

    if field.isValid():
        _patientName, _patientBirthdate, _studyDescription, _studyDate, _modality, _seriesDescription, _seriesDate, _numberOfSlices = _getImageData()
        
        gModel.insertItem(
            None,
            0,
            True,
            {
                "id": getNextId(),
                "patientName": _patientName,
                "patientBirthdate": _patientBirthdate,
                "studyDescription": _studyDescription,
                "studyDate": _studyDate,
                "modality": _modality,
                "seriesDescription": _seriesDescription,
                "seriesDate": _seriesDate,
                "sopInstanceUID": "",
            },
        )
        
        _tmpSelectedIndex = gModel.getSelectedIndex()
        
        for _sliceNumber in range(0, _numberOfSlices):
            _instanceUid = field.getFrameSpecificDicomTag("SOPInstanceUID", _sliceNumber)

            gModel.insertItem(
                _tmpSelectedIndex,
                0,
                True,
                {
                    "id": getNextId(),
                    "patientName": "",
                    "patientBirthdate": "",
                    "studyDescription": "",
                    "studyDate": "",
                    "modality": "",
                    "seriesDescription": "",
                    "seriesDate": "",
                    "sopInstanceUID": _instanceUid.value(),
                },
            )
    gInitializing = False


def itemClicked(field: "mevislab.MLABField"):
    if not gInitializing:
        columnIndex = 8
        column = gAttributes[columnIndex - 1]
        itemID = int(ctx.field("selection").value)
        data = gModel.getItemByID(itemID)[column]
        print(f"Click: {data}")

        

def _getImageData():
    _imageField = ctx.field("inImage")
    _patientName = _imageField.getDicomTagValueByName("PatientName")
    _patientBirthdate = _imageField.getDicomTagValueByName("PatientBirthDate")
    _studyDescription = _imageField.getDicomTagValueByName("StudyDescription")
    _studyDate = _imageField.getDicomTagValueByName("StudyDate")
    _modality = _imageField.getDicomTagValueByName("Modality")
    _seriesDescription = _imageField.getDicomTagValueByName("SeriesDescription")
    _seriesDate = _imageField.getDicomTagValueByName("SeriesDate")
    _numberOfSlices = _imageField.sizeZ()
    
    return _patientName, _patientBirthdate, _studyDescription, _studyDate, _modality, _seriesDescription, _seriesDate, _numberOfSlices


def getNextId():
    global gNextId
    id = gNextId
    gNextId += 1
    return id


class MyItem:
    def __init__(self, parent=None):
        self.children = []
        self.parent = parent
        self.data = {}


class MyItemModel:
    def __init__(self):
        self.model = MLAB.createMLBaseObject(
            "StandardItemModel", [["id"] + gAttributes]
        )
        root = MyItem()
        self.root = root
        self.map = {}
        pass

    def makeCurrent(self):
        ctx.field("myItemModel").setObject(self.model)

    def getRootItem(self):
        return self.root

    def getSelectedIndex(self):
        ids = [int(x) for x in ctx.field("selection").value.split()]
        if len(ids):
            return self.model.findFirst("id", ids[0])
        else:
            return None

    def addBefore(self):
        index = self.getSelectedIndex()
        if index:
            parent = self.model.getParent(index)
            pos = self.model.getChildPosition(index)
        else:
            parent = None
            pos = 0
        self.insertItem(parent, pos, True)

    def addChild(self):
        parent = self.getSelectedIndex()
        pos = self.model.getChildCount(parent)
        self.insertItem(parent, pos)

    def insertItem(self, parent, pos, updateSelection=False, data=None):
        self.model.insertItems(parent, pos, data)
        self.map[data["id"]] = data
        if updateSelection:
            ctx.field("selection").value = str(data["id"])

    def updateValues(self):
        index = self.getSelectedIndex()
        if index:
            for attr in gAttributes:
                value = ctx.field(attr).value
                if value != self.model.getData(index, attr):
                    self.model.setData(index, attr, value)
                    
    def getItemByID(self, id):
        return self.map[id]

    def clearAll(self):
        self.model.clear()
