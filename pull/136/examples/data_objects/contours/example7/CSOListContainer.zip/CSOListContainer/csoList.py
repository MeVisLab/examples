def initCSOList():
  setupCSOList()
  registerForNotification()

def setupCSOList():
  csoList = _getCSOList()
  csoList.removeAll()
  csoGroupSmall = csoList.addGroup("small")
  csoGroupLarge = csoList.addGroup("large")

  csoGroupSmall.setUsePathPointColor(True)
  csoGroupSmall.setPathPointColor((0,1,0))

  csoGroupLarge.setUsePathPointColor(True)
  csoGroupLarge.setPathPointColor((1,0,0))

def registerForNotification():
  csoList = _getCSOList()
  csoList.registerForNotification(csoList.NOTIFICATION_CSO_FINISHED, ctx, "csoFinished")

def csoFinished(_arg):
  csoList = _getCSOList()
  for cso in csoList.getCSOs():
    cso.removeFromAllGroups()
    csoArea = cso.getArea()
    csoGroup = csoList.getGroupByLabel("large")
    if csoArea <= _getAreaThreshold():
      csoGroup = csoList.getGroupByLabel("small")
    csoGroup.addCSO(cso.getId())

def _getAreaThreshold():
  return ctx.field("areaThreshold").value

def _getCSOList():
  return ctx.field("CSOListContainer.outCSOList").object()
