import cv2
import OpenCVUtils
from torchvision.io.image import read_image
from torchvision.models.segmentation import fcn_resnet50, FCN_ResNet50_Weights
from torchvision.transforms.functional import to_pil_image
import torch

_interfaces = []
camera = None

# Setup the interface for PythonImage module
def setupInterface():
  global _interfaces
  _interfaces = []
  interface = ctx.module("PythonImage").call("getInterface")
  _interfaces.append(interface)

# Grab image from camera and update
def grabImage():
  _, img = camera.read()
  updateImage(img)

# Update image in interface
def updateImage(image):
  _interfaces[0].setImage(OpenCVUtils.convertImageToML(image), minMaxValues = [0,255])

# Start capturing WebCam
def startCapture():
  global camera
  if not camera:
    camera = cv2.VideoCapture(0)
  ctx.callWithInterval(0.1, grabImage)

# Stop capturing WebCam
def stopCapture():
  ctx.removeTimers()

# Release camera in the end
def releaseCamera(_):
  global camera, _interfaces
  ctx.removeTimers()
  _interfaces = []
  if camera:
    camera.release()
    camera = None
    
def startWebcam():
  # Close previous segmentation
  ctx.module("PythonImage1").call("getInterface").unsetImage()
  # Start webcam
  startCapture()

def segmentSnapshot():
  print("Start segmentSnapshot")
  # Step 1: Get image from webcam capture
  stopCapture()
  inImage = ctx.field("PythonImage.output0").image()
  img = inImage.getTile((0,0,0,0,0,0), inImage.imageExtent())[0,0,:,0,:,:]
  print("Step 1 done")
    
  # Step 2: Convert image into torch tensor
  img = torch.Tensor(img).type(torch.uint8)
  print("Step 2 done")
    
  # Step 3: Initialize model with the best available weights
  weights = FCN_ResNet50_Weights.DEFAULT
  model = fcn_resnet50(weights=weights)
  model.eval()
  print("Step 3 done")
    
  # Step 4: Initialize the inference transforms
  preprocess = weights.transforms()
  print("Step 4 done")
    
  # Step 5: Apply inference preprocessing transforms
  batch = preprocess(img).unsqueeze(0)
  print("Step 5 done")
    
  # Step 6: Use the model to segment persons in snapshot
  prediction = model(batch)["out"]
  normalized_masks = prediction.softmax(dim=1)
  class_to_idx = {cls: idx for (idx, cls) in enumerate(weights.meta["categories"])}
  # The following classes are available and can be used for testing: # 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle',
  #  'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 'person', 'pottedplant', 'sheep',
  #  'sofa', 'train', 'tvmonitor'
  mask = normalized_masks[0, class_to_idx["person"]]
  print(class_to_idx.keys())
  print("Step 6 done")
    
  # Step 7: Set output image to module
  interface = ctx.module("PythonImage1").call("getInterface")
  interface.setImage(mask.detach().numpy())
  print("Step 7 done")
    
  # Step 8: Resize network output to original image size
  origImageSize = inImage.imageExtent()
  ctx.field("Resample3D.imageSize").value = (origImageSize[0], origImageSize[1], origImageSize[2])
  print("Step 8 done")
  
  