import torch
import numpy as np
import mevislab
from monai.bundle import load_bundle_config

# Paths
MODEL_DIR = r"C:\tmp\spleen_ct_segmentation"
MODEL_PATH = MODEL_DIR + r"\models\model_spleen_ct_segmentation_v1.pt"
TRAIN_JSON = MODEL_DIR + r"\configs\train.json"

# using cpu or cude
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def onStart():
    print("\n--- Start ---")
    try:
        inputImage = _getImage()

        if inputImage:
            imageArray = inputImage.getTile(
                (0, 0, 0, 0, 0, 0), inputImage.imageExtent()
            )
            # We only need x, y and z-dimensions
            image = imageArray[0, 0, 0, :, :, :]

            print(f"Using image {image.shape}")

            # prepare tensor
            inputTensor = torch.tensor(image[None, None, :, :, :]).to(DEVICE)
            print(f" Tensorform: {tuple(inputTensor.shape)}")
            # Load Bundle-Configuration
            parser = load_bundle_config(MODEL_DIR, "train.json")

            # Create network from train.json
            model = parser.get_parsed_content("network_def")
            model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
            model.to(DEVICE)
            model.eval()
            print("Model loaded and initialized.")

            # Inference
            with torch.no_grad():
                output = model(inputTensor)
                prediction = output.argmax(dim=1, keepdim=True).cpu().numpy()[0, 0]

            print("Inference done.")

            # Result back into MeVisLab
            interface = ctx.module("PythonImage").call("getInterface")
            interface.setImage(
                prediction, voxelToWorldMatrix=inputImage.voxelToWorldMatrix()
            )

            print("--- Segmentation done ---\n")

    except Exception as e:
        print("Error:", e)
        import traceback

        traceback.print_exc()


def _setDefaultValues():
    ctx.field("voxelSize").value = [1.5, 1.5, 2]
    ctx.field("sizeX").value = 160
    ctx.field("sizeY").value = 160
    ctx.field("sizeZ").value = 160
    ctx.field("thresholdMin").value = -57
    ctx.field("thresholdMax").value = 164
    ctx.field("scaleMin").value = 0
    ctx.field("scaleMax").value = 1

    interface = ctx.module("PythonImage").call("getInterface")
    interface.unsetImage()


def _getImage():
    if ctx.field("SwapFlipDimensions.output0").isValid():
        # Get image after all modifications have been done
        image = ctx.field("SwapFlipDimensions.output0").image()

        return image
    else:
        return None


def _sizeChanged(field: "mevislab.MLABField"):
    if ctx.field("Resample3D.output0").isValid():
        voxelSizeImage = ctx.field("Resample3D.output0").image()
        # Get the size of this image
        voxelSizeImageExtent = voxelSizeImage.imageExtent()

        # Calculate region of interest by defining start point and size
        roiStartX = voxelSizeImageExtent[0] - ctx.field("sizeX").value
        roiStartY = voxelSizeImageExtent[1] - ctx.field("sizeY").value
        roiStartZ = voxelSizeImageExtent[2] - ctx.field("sizeZ").value

        ctx.field("ROISelect.startVoxelX").value = roiStartX
        ctx.field("ROISelect.startVoxelY").value = roiStartY
        ctx.field("ROISelect.startVoxelZ").value = roiStartZ

        # Subtract 1 because the pixel values start with 0
        ctx.field("ROISelect.endVoxelX").value = voxelSizeImageExtent[0] - 1
        ctx.field("ROISelect.endVoxelY").value = voxelSizeImageExtent[1] - 1
        ctx.field("ROISelect.endVoxelZ").value = voxelSizeImageExtent[2] - 1
