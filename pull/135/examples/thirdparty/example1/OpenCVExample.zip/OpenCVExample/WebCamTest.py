# from mevis import *
import cv2
import OpenCVUtils

_interfaces = []
camera = None


# Setup the interface for PythonImage module
def setupInterface():
    global _interfaces
    _interfaces = []
    interface = ctx.module("PythonImage").call("getInterface")
    _interfaces.append(interface)


# Grab image from camera and update
def grabImage():
    _, img = camera.read()
    updateImage(img)


# Update image in interface
def updateImage(image):
    _interfaces[0].setImage(OpenCVUtils.convertImageToML(image), minMaxValues=[0, 255])


# Start capturing WebCam
def startCapture():
    global camera
    if not camera:
        camera = cv2.VideoCapture(0)
    ctx.callWithInterval(0.1, grabImage)


# Stop capturing WebCam
def stopCapture():
    ctx.removeTimers()


# Release camera in the end
def releaseCamera(_):
    global camera, _interfaces
    ctx.removeTimers()
    _interfaces = []
    if camera:
        camera.release()
        camera = None
