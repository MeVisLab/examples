
import math
from Inventor.base import SbVec3d, SbRotationd

def radians(deg):
    return deg * math.pi / 180.0

class FlightControl:

    def __init__(self):
        self._imageData          = None
        self._imageExtent        = None
        self._worldToVoxelMatrix = None

    def updateImage(self):
        image = ctx.field("inImage").image()
        if image:
            # store values for collision detection:
            self._imageExtent = image.imageExtent()
            self._imageData = image.getTile((0,0,0,0,0,0), self._imageExtent).squeeze()
            self._worldToVoxelMatrix = image.worldToVoxelMatrixInventor()

    def forward(self):
        self._move(SbVec3d(0, 0, -self._moveSpeed()))

    def backward(self):
        self._move(SbVec3d(0, 0, self._moveSpeed()))

    def left(self):
        self._move(SbVec3d(-self._moveSpeed(), 0, 0))

    def right(self):
        self._move(SbVec3d(self._moveSpeed(), 0, 0))

    def down(self):
        self._move(SbVec3d(0, -self._moveSpeed(), 0))

    def up(self):
        self._move(SbVec3d(0, self._moveSpeed(), 0))

    def rotateX(self, angle):
        self._rotate(SbRotationd(SbVec3d(0,1,0), radians(angle) * self._turnSpeed()))

    def rotateY(self, angle):
        self._rotate(SbRotationd(SbVec3d(1,0,0), radians(angle) * self._turnSpeed()))

    def rotateZ(self, angle):
        self._rotate(SbRotationd(SbVec3d(0,0,1), radians(angle) * self._turnSpeed()))

    def viewAll(self):
        ctx.field("SoCameraViewAll.viewAll").touch()
        # viewAll will set nearDistance and farDistance to the minimum required values,
        # adapt these values, so that moving around will not trigger clipping too early:
        def adaptClipping():
            ctx.field("SoPerspectiveCamera.nearDistance").value = 1
            ctx.field("SoPerspectiveCamera.farDistance").value = 10000
        ctx.callLater(0.0, adaptClipping)

    def _orientation(self):
        return ctx.field("SoPerspectiveCamera.orientation").inventorValue()

    def _move(self, relOffset):
        absOffset = self._orientation().transformPoint(relOffset)
        nextPosition = ctx.field("SoPerspectiveCamera.position").inventorValue() + absOffset
        if self._canMoveTo(nextPosition):
            ctx.field("SoPerspectiveCamera.position").setValue(nextPosition)

    def _rotate(self, rotation):
        newRotation = rotation * self._orientation()
        ctx.field("SoPerspectiveCamera.orientation").setValue(newRotation)

    def _canMoveTo(self, nextPosition):
        n = self._worldToVoxelMatrix.transformPoint(nextPosition)
        if self._isInImage(n):
            voxelValue = self._imageData[int(n[2])][int(n[1])][int(n[0])]
            return voxelValue == 0
        else:
            return True

    def _isInImage(self, position):
        return position[0] >= 0 and \
               position[1] >= 0 and \
               position[2] >= 0 and \
               position[0] < self._imageExtent[0] and \
               position[1] < self._imageExtent[1] and \
               position[2] < self._imageExtent[2]

    def _moveSpeed(self):
        return ctx.field("moveSpeed").value

    def _turnSpeed(self):
        return ctx.field("turnSpeed").value

__object__ = FlightControl()
gFlightControl = __object__

lastOffsetX = ctx.field("GenericPointingAction.offsetX").value
lastOffsetY = ctx.field("GenericPointingAction.offsetY").value

def init():
    gFlightControl.viewAll()

def onKeyPressed():
    key = ctx.field("SoKeyGrabber.lastKey").value
    if key == "W":
        gFlightControl.forward()
    elif key == "S":
        gFlightControl.backward()
    elif key == "A":
        gFlightControl.left()
    elif key == "D":
        gFlightControl.right()
    elif key == "C":
        gFlightControl.down()
    elif key == "SPACE":
        gFlightControl.up()
    elif key == "LEFT_ARROW":
        gFlightControl.rotateX(5)
    elif key == "RIGHT_ARROW":
        gFlightControl.rotateX(-5)
    elif key == "UP_ARROW":
        gFlightControl.rotateY(5)
    elif key == "DOWN_ARROW":
        gFlightControl.rotateY(-5)
    elif key == "COMMA":
        gFlightControl.rotateZ(5)
    elif key == "PERIOD":
        gFlightControl.rotateZ(-5)
    elif key == "V":
        gFlightControl.viewAll()

def onHeadNod(field):
    global lastOffsetX
    oldOffsetX = lastOffsetX
    lastOffsetX = field.value
    deltaX =  lastOffsetX - oldOffsetX
    if deltaX:
        gFlightControl.rotateY(deltaX)

def onHeadTurn(field):
    global lastOffsetY
    oldOffsetY = lastOffsetY
    lastOffsetY = field.value
    deltaY =  lastOffsetY - oldOffsetY
    if deltaY:
        gFlightControl.rotateX(-deltaY)

def onUpdateImage():
    gFlightControl.updateImage()
