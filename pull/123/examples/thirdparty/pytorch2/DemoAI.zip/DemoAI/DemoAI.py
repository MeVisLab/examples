import torch


def onStart():
    # Step 1: Get input image
    image = ctx.field("inputImage").image()
    imageArray = image.getTile((0, 0, 0, 0, 0, 0), image.imageExtent())
    inputImage = imageArray[0,0,0,:,:,:].astype("float")
    
    # Step 2: Normalize input image
    values = inputImage[inputImage > inputImage.mean()]
    inputImage = (inputImage - values.mean()) / values.std()
    
    # Step 3: Convert into torch tensor of size: [Batch, Channel, z, y, x]
    inputTensor = torch.Tensor(inputImage[None, None, :, :, :])
    
    # Step 4: Load and prepare AI model
    device = torch.device("cpu")
    model = torch.hub.load("fepegar/highresnet", "highres3dnet", pretrained=True, trust_repo=True)
    model.to(device).eval()
        
    # Step 5: Use model to segment brain parts
    print('Start prediction - please wait...')
    with torch.autocast(device.type):
        output = model(inputTensor.to(device))
    brainParcellationMap = output.argmax(dim=1, keepdim=True).cpu()[0]
    print('...done.')

    # Step 6: Set output image to module
    interface = ctx.module("PythonImage").call("getInterface")
    interface.setImage(brainParcellationMap.numpy(), voxelToWorldMatrix=image.voxelToWorldMatrix())

