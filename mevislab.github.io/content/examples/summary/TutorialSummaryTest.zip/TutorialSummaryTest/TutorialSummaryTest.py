#
# Copyright 2023, MeVis Medical Solutions AG
#
# The user may use this file in accordance with the license agreement provided with
# the Software or, alternatively, in accordance with the terms contained in a
# written agreement between the user and MeVis Medical Solutions AG.
#
# For further information use the contact form at https://www.mevislab.de/contact
#

from mevis import *
from TestSupport import Base, Fields, Logging, ScreenShot
from TestSupport.Macros import *

# Parameters
path_to_image = "$(DemoDataPath)/BrainMultiModal/ProbandT1.dcm"
marker_location = [-29, -26, 45]
marker_location_new = [-20, -30, 35]
new_color = [0.5, 0.5, 0]


# Test functions
# Requirement 1: The application shall be able to load DICOM data
def TEST_01LoadDICOMData():
    # Set path to image and expect a valid image
    loadImage(path_to_image)
    ASSERT_TRUE(
        isImageValid(),
        "Requirement 1: The application shall be able to load DICOM data: Load a valid image.",
    )
    # Reset again and expect an invalid image
    reset()
    ASSERT_FALSE(
        isImageValid(),
        "Requirement 1: The application shall be able to load DICOM data: After reset, no image shall be loaded.",
    )


# Requirement 4: The 2D viewer shall provide the possibility to segment parts of the image based on a RegionGrowing algorithm
# Requirement 4.1: It shall be possible to click into the image for defining a marker position for starting the RegionGrowing
# Requirement 4.2: It shall be possible to define a threshold for the RegionGrowing algorithm
def TEST_02RegionGrowing():
    # Load image and expect volumes and voxels without marker to be 0
    loadImage(path_to_image)
    region_growing_voxels = ctx.field(
        "TutorialSummary.RegionGrowing.numSegmentedVoxels"
    ).value
    region_growing_volume = ctx.field(
        "TutorialSummary.RegionGrowing.segmentedVolume_ml"
    ).value
    ASSERT_EQ(
        region_growing_voxels,
        0,
        "Requirement 4: The 2D viewer shall provide the possibility to segment parts of the image based on a RegionGrowing algorithm: Image available but no marker set.",
    )
    ASSERT_EQ(
        region_growing_volume,
        0,
        "Requirement 4: The 2D viewer shall provide the possibility to segment parts of the image based on a RegionGrowing algorithm: Image available but no marker set.",
    )
    # Set marker and expect volumes and voxels to be larger than 0
    setMarkerPosition(marker_location)
    region_growing_voxels = ctx.field(
        "TutorialSummary.RegionGrowing.numSegmentedVoxels"
    ).value
    region_growing_volume = ctx.field(
        "TutorialSummary.RegionGrowing.segmentedVolume_ml"
    ).value
    ASSERT_GT(
        region_growing_voxels,
        0,
        "Requirement 4.1: It shall be possible to click into the image for defining a marker position for starting the RegionGrowing: Image and Marker available, region growing started.",
    )
    ASSERT_GT(
        region_growing_volume,
        0,
        "Requirement 4.1: It shall be possible to click into the image for defining a marker position for starting the RegionGrowing: Image and Marker available, region growing started.",
    )
    # Test the threshold functionality by changing the value and comparing the results
    current_threshold = ctx.field("TutorialSummary.thresholdInterval").value
    current_threshold = current_threshold + 0.5
    ctx.field("TutorialSummary.thresholdInterval").value = current_threshold
    region_growing_voxels_new = ctx.field(
        "TutorialSummary.RegionGrowing.numSegmentedVoxels"
    ).value
    region_growing_volume_new = ctx.field(
        "TutorialSummary.RegionGrowing.segmentedVolume_ml"
    ).value
    ASSERT_GT(
        region_growing_voxels_new,
        region_growing_voxels,
        "Requirement 4.2: It shall be possible to define a threshold for the RegionGrowing algorithm: Threshold increased",
    )
    ASSERT_GT(
        region_growing_volume_new,
        region_growing_volume,
        "Requirement 4.2: It shall be possible to define a threshold for the RegionGrowing algorithm: Threshold increased",
    )
    current_threshold = current_threshold - 0.7
    ctx.field("TutorialSummary.thresholdInterval").value = current_threshold
    region_growing_voxels_new = ctx.field(
        "TutorialSummary.RegionGrowing.numSegmentedVoxels"
    ).value
    region_growing_volume_new = ctx.field(
        "TutorialSummary.RegionGrowing.segmentedVolume_ml"
    ).value
    ASSERT_LT(
        region_growing_voxels_new,
        region_growing_voxels,
        "Requirement 4.2: It shall be possible to define a threshold for the RegionGrowing algorithm: Threshold decreased",
    )
    ASSERT_LT(
        region_growing_volume_new,
        region_growing_volume,
        "Requirement 4.2: It shall be possible to define a threshold for the RegionGrowing algorithm: Threshold decreased",
    )
    # Reset application and expect volumes and voxels to be 0 again
    reset()
    region_growing_voxels = ctx.field(
        "TutorialSummary.RegionGrowing.numSegmentedVoxels"
    ).value
    region_growing_volume = ctx.field(
        "TutorialSummary.RegionGrowing.segmentedVolume_ml"
    ).value
    ASSERT_EQ(
        region_growing_voxels,
        0,
        "Requirement 4: The 2D viewer shall provide the possibility to segment parts of the image based on a RegionGrowing algorithm: No region growing after reset.",
    )
    ASSERT_EQ(
        region_growing_volume,
        0,
        "Requirement 4: The 2D viewer shall provide the possibility to segment parts of the image based on a RegionGrowing algorithm: No region growing after reset.",
    )


# Requirement 5.1: It shall be possible to define the color of the overlay
def TEST_05OverlayColor():
    reset()
    loadImage(path_to_image)
    setMarkerPosition(marker_location)
    ctx.field("SoCameraInteraction.viewAll").touch()
    ctx.field("SoCameraInteraction.viewFromLeft").touch()
    MLAB.processInventorQueue()
    ctx.field("OffscreenRenderer.update").touch()
    MLAB.processInventorQueue()
    current_color = ctx.field("TutorialSummary.selectOverlayColor").value
    ctx.field("TutorialSummary.selectOverlayColor").setValue(new_color)
    ctx.field("SoCameraInteraction.viewAll").touch()
    ctx.field("SoCameraInteraction.viewFromLeft").touch()
    MLAB.processInventorQueue()
    ctx.field("OffscreenRenderer1.update").touch()
    MLAB.processInventorQueue()
    ASSERT_NE(
        current_color,
        ctx.field("TutorialSummary.selectOverlayColor").value,
        "Requirement 5.1: It shall be possible to define the color of the overlay: Changed color differs from original color.",
    )
    ASSERT_EQ(
        ctx.field("TutorialSummary.selectOverlayColor").value,
        ctx.field("TutorialSummary.SoView2DOverlay.baseColor").value,
        "Requirement 5.1: It shall be possible to define the color of the overlay: Macro Module and 2D overlay colors are equal.",
    )
    ASSERT_EQ(
        ctx.field("TutorialSummary.selectOverlayColor").value,
        ctx.field("TutorialSummary.SoWEMRendererSegmentation.faceDiffuseColor").value,
        "Requirement 5.1: It shall be possible to define the color of the overlay: Macro Module and 3D colors are equal.",
    )
    ASSERT_FALSE(
        ctx.field("ImageCompare.testPassed").value,
        "Requirement 5.1: It shall be possible to define the color of the overlay: 3D image changed after changing the color.",
    )


# Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml)
def TEST_03VolumeCalculation():
    # Reset and expect all volumes and number of voxels to be 0
    reset()
    reference_volume = ctx.field("CalculateVolume.totalVolume").value
    ASSERT_EQ(
        reference_volume,
        0,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Initial volume shall be 0.",
    )
    # Load patient, set marker and expect all volumes and number of voxels to be > 0
    loadImage(path_to_image)
    reference_volume = ctx.field("CalculateVolume.totalVolume").value
    ASSERT_EQ(
        reference_volume,
        0,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Volume without marker shall be 0.",
    )
    setMarkerPosition(marker_location)
    reference_volume = ctx.field("CalculateVolume.totalVolume").value
    current_volume = ctx.field("TutorialSummary.totalVolume").value
    # Expect the total volume of the application to be the same as our additional CalculateVolume module
    ASSERT_GT(
        reference_volume,
        0,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Volume with marker shall be greater than 0.",
    )
    ASSERT_EQ(
        reference_volume,
        current_volume,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Volume shall equal CalculateVolume result.",
    )
    # set marker to a different location and check if volumes change.
    setMarkerPosition(marker_location_new)
    reference_volume_new = ctx.field("CalculateVolume.totalVolume").value
    current_volume_new = ctx.field("TutorialSummary.totalVolume").value
    ASSERT_NE(
        reference_volume,
        reference_volume_new,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Changing marker shall update the volume.",
    )
    ASSERT_NE(
        current_volume,
        current_volume_new,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Changing marker shall update the volume.",
    )
    ASSERT_EQ(
        reference_volume_new,
        current_volume_new,
        "Requirement 8: The total volume of the segmented area shall be calculated and shown (in ml): Changing marker shall calculate the same volume as CalculateVolume module.",
    )


# Requirement 9: It shall be possible to toggle the visible 3D objects
# Requirement 9.1: Original data
# Requirement 9.2: Segmentation results
# Requirement 9.3: All
def TEST_04Toggle3DVolumes():
    # Set ImageCompare.postErrorOnDiff to False because otherwise differences will lead to a failed test
    ctx.field("ImageCompare.postErrorOnDiff").value = False
    # Reset application and check if number of voxels is 0 on output
    reset()
    loadImage(path_to_image)
    # Without marker, the content of the 3D viewer should be the same for File and All
    ctx.field("TutorialSummary.selected3DView").value = "Both"
    MLAB.processInventorQueue()
    ctx.field("SoCameraInteraction.viewFromLeft").touch()
    MLAB.processInventorQueue()
    ctx.field("OffscreenRenderer.update").touch()
    ctx.field("TutorialSummary.selected3DView").value = "File"
    MLAB.processInventorQueue()
    ctx.field("OffscreenRenderer1.update").touch()
    ctx.field("ImageCompare.compare").touch()
    ASSERT_TRUE(
        ctx.field("ImageCompare.testPassed").value,
        "Requirement 9: It shall be possible to toggle the visible 3D objects: Without segmentation, Both and File show the same image.",
    )
    # With marker, the content of the 3D viewer should be different
    setMarkerPosition(marker_location)
    ctx.field("TutorialSummary.selected3DView").value = "Both"
    MLAB.processInventorQueue()
    ctx.field("OffscreenRenderer.update").touch()
    ctx.field("TutorialSummary.selected3DView").value = "File"
    ctx.field("OffscreenRenderer1.update").touch()
    MLAB.processInventorQueue()
    ctx.field("ImageCompare.compare").touch()
    ASSERT_FALSE(
        ctx.field("ImageCompare.testPassed").value,
        "Requirement 9.1: Original data and Requirement 9.3: All.",
    )
    ctx.field("TutorialSummary.selected3DView").value = "Segmented"
    ctx.field("OffscreenRenderer1.update").touch()
    MLAB.processInventorQueue()
    ctx.field("ImageCompare.compare").touch()
    ASSERT_FALSE(
        ctx.field("ImageCompare.testPassed").value,
        "Requirement 9.1: Original data and Requirement 9.2: Segmentation results.",
    )
    ctx.field("TutorialSummary.selected3DView").value = "Both"
    ctx.field("OffscreenRenderer.update").touch()
    MLAB.processInventorQueue()
    ctx.field("ImageCompare.compare").touch()
    ASSERT_FALSE(
        ctx.field("ImageCompare.testPassed").value,
        "Requirement 9.2: Segmentation results and Requirement 9.1: Original data.",
    )


# Helper functions
# Load an image from the given path.
def loadImage(full_path):
    MLAB.log("Setting image path to '" + full_path + "'...")
    ctx.field("TutorialSummary.openFile").value = full_path


# Check if a valid image is available at the output out2D (returns True for a valid image)
def isImageValid():
    MLAB.log("Checking if image is valid...")
    data_valid = ctx.field("TutorialSummary.out2D").isValid()
    if data_valid:
        return True
    else:
        return False


# Sets the marker to the given 3-dimensional vector position and clicks applyMarker
def setMarkerPosition(vector):
    MLAB.log(
        "Setting marker position to ["
        + str(vector[0])
        + ","
        + str(vector[1])
        + ","
        + str(vector[2])
        + "]..."
    )
    ctx.field("TutorialSummary.markerPosition").setValue(
        vector[0], vector[1], vector[2]
    )
    ctx.field("TutorialSummary.applyMarker").touch()
    MLAB.processEvents()
    while not ctx.field("TutorialSummary.outSegmentationMask").isValid():
        MLAB.msleep(100)
        MLAB.processEvents()
    MLAB.log(
        "Marker position set to '"
        + str(ctx.field("TutorialSummary.markerPosition").value)
        + "'..."
    )


# Touches the resetApplication trigger
def reset():
    MLAB.log("Resetting application...")
    ctx.field("TutorialSummary.resetApplication").touch()
