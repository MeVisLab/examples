define({
  load: function(name, parentRequire, onload, config) {

    MLAB.createNamespace("TutorialSummaryBrowser")
    
    MLAB.TutorialSummaryBrowser.deriveClass("Plugin", MLAB.GUI.PluginBase, {
      Plugin: function(config) {
        MLAB.TutorialSummaryBrowser.Plugin.super.constructor.call(this, config)

        // Arguments are accessible via 'config.applicationArguments', e.g.:
        //
        // if ("mySetting" in config.applicationArguments) {
        //   var settingValue = config.applicationArguments["mySetting"]
        // }
      },
      
      setup: function(finishCallback) {
        this.loadStyles(["../css/default.css"])
        
        // Connect to the modulesAreReady signal, which indicates that the web macro module
        // is completely initialized.
        MLAB.GUI.Application.connect("modulesAreReady", this, "_handleModulesAreReady")
        
        // Notify the application that we are finished now.
        finishCallback(this)

        // Use this code to load additional javascript files next to this plugin:
        //
        // require.config({baseUrl: this.resourcesBaseUrl()})
        // require(["file0.js", "file1.js", ..], (function() {
        //   finishCallback(this)
        // }).bind(this))
      },
      
      _handleModulesAreReady: function() {
        // The web macro module is completely initialized. We can show the main panel now.
        this.module().showPanel("MainPanel", document.body)
      },
    })
    
    var plugin = new MLAB.TutorialSummaryBrowser.Plugin(config)
    plugin.setup(onload)
  },
})
