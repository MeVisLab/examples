# SPDX-License-Identifier: CC0-1.0

# 
#  \file    TutorialSummary.py
#  \author  MeVis Medical Solutions AG
#  \date    2023-01-16
#
#  Macro Module for MeVisLab Tutorials

# ----------------------------------------------------------------------------

from mevis import *

def viewSelectionChanged(field):
  if field.value == "Segmented":
    ctx.field("SoSwitch.whichChild").value = 0
  if field.value == "File":
    ctx.field("SoSwitch.whichChild").value = 1
  if field.value == "Both":
    ctx.field("SoSwitch.whichChild").value = 2

def resetApplication():
  ctx.field("RegionGrowing.clear").touch()
  ctx.field("SoView2DMarkerEditor.deleteAll").touch()
  ctx.field("LocalImage.close").touch()
  ctx.field("imageAlpha").value = 0.5
  ctx.field("thresholdInterval").value = 1.0
  ctx.field("isoValueImage").value = 200
  ctx.field("selected3DView").value = "Both"

def insertPosition(field):
  ctx.field("SoView2DMarkerEditor.newPosXYZ").value = field.value

def applyPosition():
  ctx.field("SoView2DMarkerEditor.useInsertTemplate").value = True
  ctx.field("SoView2DMarkerEditor.add").touch()

