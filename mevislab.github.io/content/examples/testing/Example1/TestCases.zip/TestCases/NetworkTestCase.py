# SPDX-License-Identifier: CC0-1.0

from mevis import *
from TestSupport import Base, Fields, Logging, ScreenShot
from TestSupport.Macros import *

# user your own path
filePath = "C:/Users/AppData/Local/MeVisLab3.5.90/Packages/MeVisLab/Resources/DemoData/BrainT1Dicom"


def OpenDicom():
    ctx.field("DicomImport.inputMode").value = "Directory"
    ctx.field("DicomImport.source").value = filePath
    ctx.field("DicomImport.triggerImport").touch()
    MLAB.processEvents()
    # Base.ignoreWarningAndError(MLAB.processEvents)
    while not ctx.field("DicomImport.ready").value:
        MLAB.sleep(1)
        Base.ignoreWarningAndError(MLAB.processEvents)
    ctx.field("DicomImport.selectNextItem").touch()
    MLAB.log("path: " + ctx.field("DicomImport.source").value)


def TEST_FileExist():
    isExist = os.path.exists(filePath)
    ASSERT_TRUE(isExist)


def TEST_DicomImport():
    expectValue = 1.0
    OpenDicom()
    actualValue = ctx.field("DicomImport.progress").value
    ASSERT_FLOAT_EQ(expectValue, actualValue)


def TEST_MaxValue():
    OpenDicom()
    maxValue = ctx.field("MinMaxScan.trueMaxValue").value
    condition = maxValue > 0
    if not condition:
        MLAB.logError("Max value is zero")
    else:
        print(str(maxValue) + "Ok: is not zero")


# This function check if the View3D-input and DicomImport-output have the same date
def TEST_CheckInputAndOutput():
    OpenDicom()
    view3DInput = ctx.field("View3D.inImage").size3D()
    dicomImportOutput = ctx.field("DicomImport.output0").size3D()
    ASSERT_EQ(dicomImportOutput, view3DInput)
